create function format_path(path varchar(512))
  returns varchar(512)
  comment '
 Description
 
 Takes a raw path value, and strips out the datadir or tmpdir
 replacing with @@datadir and @@tmpdir respectively. 
 
 Also normalizes the paths across operating systems, so backslashes
 on Windows are converted to forward slashes
 
 Parameters
 
 path (VARCHAR(512)):
 The raw file path value to format.
 
 Returns
 
 VARCHAR(512) CHARSET UTF8
 
 Example
 
 mysql> select @@datadir;
 +-----------------------------------------------+
 | @@datadir                                     |
 +-----------------------------------------------+
 | /Users/mark/sandboxes/SmallTree/AMaster/data/ |
 +-----------------------------------------------+
 1 row in set (0.06 sec)
 
 mysql> select format_path(''/Users/mark/sandboxes/SmallTree/AMaster/data/mysql/proc.MYD'') AS path;
 +--------------------------+
 | path                     |
 +--------------------------+
 | @@datadir/mysql/proc.MYD |
 +--------------------------+
 1 row in set (0.03 sec)
 '
  BEGIN DECLARE v_path VARCHAR(512); DECLARE v_undo_dir VARCHAR(1024);  IF path LIKE '/private/%'  THEN SET v_path = REPLACE(path, '/private', ''); ELSE SET v_path = path; END IF;  SET v_undo_dir = IFNULL((SELECT VARIABLE_NAME FROM performance_schema.global_variables WHERE VARIABLE_NAME = 'innodb_undo_directory'), '');  IF v_path IS NULL THEN RETURN NULL; ELSEIF v_path LIKE CONCAT(@@global.datadir, '%') ESCAPE '|' THEN RETURN REPLACE(REPLACE(REPLACE(v_path, @@global.datadir, '@@datadir/'), '\\\\', ''), '\\', '/'); ELSEIF v_path LIKE CONCAT(@@global.tmpdir, '%') ESCAPE '|' THEN RETURN REPLACE(REPLACE(REPLACE(v_path, @@global.tmpdir, '@@tmpdir/'), '\\\\', ''), '\\', '/'); ELSEIF v_path LIKE CONCAT(@@global.slave_load_tmpdir, '%') ESCAPE '|' THEN RETURN REPLACE(REPLACE(REPLACE(v_path, @@global.slave_load_tmpdir, '@@slave_load_tmpdir/'), '\\\\', ''), '\\', '/'); ELSEIF v_path LIKE CONCAT(@@global.innodb_data_home_dir, '%') ESCAPE '|' THEN RETURN REPLACE(REPLACE(REPLACE(v_path, @@global.innodb_data_home_dir, '@@innodb_data_home_dir/'), '\\\\', ''), '\\', '/'); ELSEIF v_path LIKE CONCAT(@@global.innodb_log_group_home_dir, '%') ESCAPE '|' THEN RETURN REPLACE(REPLACE(REPLACE(v_path, @@global.innodb_log_group_home_dir, '@@innodb_log_group_home_dir/'), '\\\\', ''), '\\', '/'); ELSEIF v_path LIKE CONCAT(v_undo_dir, '%') ESCAPE '|' THEN RETURN REPLACE(REPLACE(REPLACE(v_path, v_undo_dir, '@@innodb_undo_directory/'), '\\\\', ''), '\\', '/'); ELSE RETURN v_path; END IF; END;

